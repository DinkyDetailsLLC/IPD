//
//  ClientInfo.m
//  SnowPush
//
//  Created by Dannis on 9/25/14.
//  Copyright (c) 2014 Dannis. All rights reserved.
//

#import "ClientInfo.h"

@implementation ClientInfo
@synthesize Comp_name,ContractCost,Email,SeasonalCost,State,City,phoneNo,Image,Address,TripCost,Zip,date,startTime,finishTime;
@synthesize salt,shovel,plow,removal,hours,calculated,contract,seasonal,trip,sendInVoice,paidInFull;
@synthesize imageAfter,imageBefore,snowFall;
@end
