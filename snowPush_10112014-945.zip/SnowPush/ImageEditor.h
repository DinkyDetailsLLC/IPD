#import "ImageEditorViewController.h"

@interface ImageEditor : ImageEditorViewController

@property(nonatomic,strong) IBOutlet UIBarButtonItem *saveButton;

@end
