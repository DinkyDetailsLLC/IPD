#import <UIKit/UIKit.h>
#import "ImageEditorViewController.h"

@interface ImageEditorFrameView : UIView<HFImageEditorFrame>

@end
